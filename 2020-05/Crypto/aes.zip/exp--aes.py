from Crypto.Util.number import *
from Crypto.Cipher import AES
import binascii

xor = long_to_bytes(90926871081571161194595407500070147462209837708641640210880175133515040096532)
key = xor[: 16] * 2
iv = long_to_bytes(bytes_to_long(key) ^ bytes_to_long(xor))
aes = AES.new(key, AES.MODE_CBC, iv)
enc_flag = aes.decrypt(binascii.a2b_hex("33fdfa9d0f94a06f83eeabb40714b5bb29110a87000c18f20e1d8c18196a8cbe"))
print enc_flag
'''
NCTF{oh!!!a35_m4yb3_I5_50L1d??!}
'''