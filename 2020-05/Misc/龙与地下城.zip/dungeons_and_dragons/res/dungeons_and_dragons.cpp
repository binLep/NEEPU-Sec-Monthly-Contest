#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <limits.h>
using namespace std;

int money = 5;
int power = 5;

class Shop{
public:

    int choose;
    int times;
    int increase;
    Shop(){
        cout << "要买点什么呢？" << endl << endl;
        cout << "1,强化装备(20金币)" << endl;
        cout << "2,返回" << endl << endl;
    }
    int result(){
        cout << "请输入你的选择：";
        cin >> choose;
        cin.clear();
        cin.ignore(LLONG_MAX, '\n');

        switch(choose){
        case 1:
            cout << "请输入要强化的次数：";
            cin >> times;
            cin.clear();
            cin.ignore(LLONG_MAX, '\n');
            if(money - 20 * times > 0){
                power = power + 50 * times;
                money = money - 20 * times;

                cout << "花费了" << 20 * times << endl;
                cout << "战斗力上升了" << 50 * times << endl;

            }
            else{
                cout << "钱不够..." << endl;
            }
            break;
        case 2:
            cout << "你离开了";
        }
    }
};


class Monster{
public:

    int choose;
    int increase;

    Monster(){
        cout << "要讨伐的怪物是：" << endl << endl;
        cout << "1,史莱姆 (战斗力1)" << endl;
        cout << "2,黑龙 (战斗力9999999)" << endl;
        cout << "3,返回" << endl << endl;
    }
    char result(){
        cout << "请输入你的选择：";
        cin >> choose;
        cin.clear();
        cin.ignore(LLONG_MAX, '\n');

        cout << endl;
        switch(choose){
        case 1:
            increase = 1 + rand() % 3;
            money = money + increase;
            cout << "战斗中..." << endl;
            sleep(2);
            cout << "你战胜了史莱姆，获得了" << increase << "个金币" << endl;
            break;
        case 2:
        {
            if(power > 9999999){
                system("cat /flag");
                exit(0);
            }
            else{
                cout << "你死了" << endl;
                cout << "你转生成了勇者" << endl;
                money = 5;
                power = 5;
            }
            break;
        }
        case 3:
        {
            cout << "你逃离了怪物" << endl;
        }
        }
    }
};

char menu(){
    cout << "你是一位勇者，为了打败传说中的恶龙获得 flag 而离开家乡不断磨练自己..." << endl;
    cout << "现在的战斗力是：" << power << endl;
    cout << "拥有的金币是：" << money << endl;
    cout << "今天要做什么呢？" << endl << endl;
    cout << "1,野外战斗" << endl;
    cout << "2,商店购物" << endl;
    cout << "3,人生重来" << endl << endl;
    cout << "请输入你的选择：";
}

int main(){
    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);
    int choose;

    while(true){
        system("clear");
        menu();

        cin >> choose;
        cin.clear();
        cin.ignore(LLONG_MAX, '\n');

        switch(choose){
        case 1:
        {
            system("clear");
            Monster pl_mon;
            pl_mon.result();
            cout << "请按回车键继续..." << endl;
            getchar();
            break;
        }
        case 2:
        {
            system("clear");
            Shop pl_sh;
            pl_sh.result();
            cout << "请按回车键继续..." << endl;
            getchar();
            break;
        }
        case 3:
        {
            system("clear");
            money = 5;
            power = 5;
            cout << "你转生成了勇者" << endl;
            cout << "请按回车键继续..." << endl;
            getchar();
        }
        }
    }
}

