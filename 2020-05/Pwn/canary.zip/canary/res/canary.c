#include <stdio.h>
#include <stdlib.h>

int main(){
    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);
    char buf[0x60];
    puts("Welcome to NCTF canary");
    puts("The first read bridge");
    read(0, buf, 0x100);
    printf("your first input is %s", buf);
    puts("The second read bridge");
    read(0, buf, 0x100);
    printf("your second input is %s", buf);
    puts("I have received your message, Thank you!");
    return 0;
}
