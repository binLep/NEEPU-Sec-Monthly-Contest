#include <stdio.h>
#include <stdlib.h>

void target(){
    puts("U fing it!!!");
    system("/bin/sh");
}

int main(){
    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);
    char buf[0x60];
    puts("Welcome to NCTF ret2text");
    puts("Please input something to get flag");
    read(0, buf, 0x100);
    puts("I have received your message, Thank you!");
    return 0;
}
