<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Best PHP</title>
    <script src="JS/jquery.min.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
	<style>
	body
	{
		width:500px;
		margin:0 auto;
	}
	</style>
</head>

<body>
<?php
error_reporting(0);
session_start();

if(!isset($_SESSION['score']))
{
	$_SESSION['score']=0;
}


if(isset($_SESSION['score']))
{
	$answer = $_POST['answer'];
	if($_SESSION['score']===0)
	{
		$content="第一题：小明想要一个3位大于999的字符串，你知道是什么吗？";
		if(strlen($answer)===3&&$answer>999)
		{
			$_SESSION['score'] = 1;
			$output="";
		}
		elseif($answer){
			$output="Not This";
		}
	}
	if($_SESSION['score']===1)
	{
		$content="第二题：小明很喜欢cxk，如果答案中存在song_jump_basketball就会通过，但是这个网站会过滤掉字符串中以song开头ball结尾的内容，你能提交正确的答案吗？";
		
		if(!preg_match('/^song.*?basketball$/', $answer) && strpos($answer,'song_jump_basketball')!==false)
		{
			$_SESSION['score'] = 2;
		}
		elseif($answer){
			$output="Not This";
			$output="";
		}
	}
	if($_SESSION['score']===2)
	{
		$content="第三题：当前目录下存在Right.txt和Wrong.txt，你可以读取文件内容，内容是Right即可通过，但是小明写了两个Wrong，你能否将回显变为Right？<br>";
		
		if(strpos($answer,'index.php')===false)
		{
			$result = file_get_contents($answer);
			if($result==='Right')
			{
				echo file_get_contents("/flaagg");
			}
		}
	}
}

?>
	<br>
	<div class="panel panel-primary">
	  <div class="panel-heading">
		<h3 class="panel-title">题目</h3>
	  </div>
	  <div class="panel-body">
		<?php echo $content."<br><br>";?>
		<form method='post'>
                <div class="input-group">
                    <input type="text" class="form-control"  placeholder="请输入答案" name="answer">
                    <span class="input-group-btn">
					<button class="btn btn-default" type="submit">提交</button>
				  </span>
                </div>
		</form>
		<?php echo "<br>".$output;?>
	  </div>
	</div>


</body>



