import subprocess
from flask import request
from flask import redirect
from flask import url_for
from flask import render_template_string
from flask import render_template
from flask import Flask


app = Flask(__name__)


@app.route('/',methods=['GET','POST'])
def index():
    if request.method == 'POST':
        message=request.form['message']
        return render_template_string(message)
    else:
        return render_template("heart.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0")
