#!/usr/bin/env python
# -*- coding: utf-8 -*-
from Crypto.Cipher import AES
from FLAG import flag
import binascii


class prpcrypt():
    def __init__(self, key, iv):
        self.key = key
        self.iv = iv
        self.mode = AES.MODE_CBC

    def encrypt(self, text):
        cryptor = AES.new(self.key, self.mode, self.iv)
        length = 24
        count = len(text)
        if count % length != 0:
            add = length - (count % length)
        else:
            add = 0
        text = text + ('\0' * add)
        return binascii.hexlify(cryptor.encrypt(text))

    def decrypt(self, text):
        cryptor = AES.new(self.key, self.mode, self.iv)
        plain_text = cryptor.decrypt(binascii.unhexlify(text))
        return plain_text.rstrip('\0')


pc = prpcrypt('In_fact_binLep_is_boring', '\x00' * 16)
e = pc.encrypt(flag)
print '[\033[0;32m+\033[0m]cipher = ' + e

