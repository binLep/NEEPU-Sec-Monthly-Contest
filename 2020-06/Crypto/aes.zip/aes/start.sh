#!/bin/sh

# local
echo 'flag = "'`cat flag`'"' > /home/ctf/FLAG.py
# remote
echo 'flag = "'$FLAG'"' > /home/ctf/FLAG.py

chown root:ctf /home/ctf/flag

# start ctf-xinetd
/etc/init.d/xinetd start; 
trap : TERM INT; 
sleep infinity & wait