#!/usr/bin/env python
# -*- coding: utf-8 -*-
from Crypto.Util.number import *
from FLAG import flag
import binascii

p = getPrime(0x500)
q = getPrime(0x500)
n = p * q
e = 3
m = int(binascii.hexlify(flag), 16)
c = pow(m, e, n)
print '[\033[0;32m+\033[0m]c = ' + hex(c)
print '[\033[0;32m+\033[0m]e = ' + hex(e)
print '[\033[0;32m+\033[0m]n = ' + hex(n)
