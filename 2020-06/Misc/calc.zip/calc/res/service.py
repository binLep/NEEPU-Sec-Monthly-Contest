#!/usr/bin/env python
# -*- coding: utf-8 -*-

print('1+1=?')
answer = input()
if answer == 2:
    print 'you are right'
else:
    print 'wrong'

