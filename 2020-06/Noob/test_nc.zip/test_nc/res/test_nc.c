#include <stdio.h>

int main(){
    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);
    system("sh");
    return 0;
}
// gcc pwn.c -z execstack -z norelro -no-pie -fno-stack-protector -o pwn
