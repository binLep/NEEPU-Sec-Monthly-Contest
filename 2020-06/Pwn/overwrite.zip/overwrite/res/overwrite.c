#include <stdio.h>

int main(){
    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);
    char a = 'N';
    char b[0x20] = {0};
    write(1, "H31lo JuNe~\n", 12);
    scanf("%s", b);
    if(a == 'Y'){
        system("sh");
    }
    return 0;
}
// gcc pwn.c -z execstack -z norelro -no-pie -fno-stack-protector -o pwn
