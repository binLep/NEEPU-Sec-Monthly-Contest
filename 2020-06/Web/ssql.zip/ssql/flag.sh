#!/usr/bin/env sh
mysql -e "create database neepusec_ctf; use neepusec_ctf;source /db.sql; UPDATE secret SET flag = '$FLAG';" -uroot -proot

export FLAG=not_flag
FLAG=not_flag

rm -rf /db.sql
rm -rf /flag.sh
