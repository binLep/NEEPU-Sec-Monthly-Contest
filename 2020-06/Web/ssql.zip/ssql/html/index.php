<?php
error_reporting(0);
function waf($str)
	{
		$str=str_ireplace("and","waf",$str);
		$str=str_ireplace("or","waf",$str);
		$str=str_ireplace("|","waf",$str);
		$str=str_ireplace("&","waf",$str);
		$str=str_ireplace("#","waf",$str);
		$str=str_ireplace("-","waf",$str);
		$str=str_ireplace("sleep","waf",$str);
		$str=str_ireplace("if","waf",$str);
		$str=str_ireplace("flag","waf",$str);
		return $str;
	}
$coon = mysqli_connect("localhost","root","root");                    
mysqli_select_db($coon,"neepusec_ctf");

$ccc = waf($_GET['ccc']);
$num = preg_match('/waf/',$ccc);


if($num!=0)
{
	echo " &nbsp  &nbsp  &nbsp not this";
	die();
}
else
{
	$sql = "select * from chat order by id ".$ccc ;
	$result=mysqli_query($coon,$sql);
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>HELP</title>
    <script src="JS/jquery.min.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
	<style>
	body
	{
		width:470px;
		margin:0 auto;
	}
	</style>
</head>

<body>
	<br><br>
	<div class="panel panel-default">
	  <div class="panel-heading">
	  
		<h4>Chat Log &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <a href='<?php echo $_SERVER['PHP_SELF'].'?ccc=desc'; ?>'> hint </a></h4>
	
	  </div>
		<ul class="list-group">
		<?php 
		while($row = mysqli_fetch_array($result)) {
			echo '<li class="list-group-item">'.$row['content'].'</li>';
		}
		?>
	  </ul>
	</div>


</body>




