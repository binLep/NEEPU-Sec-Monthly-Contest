#!/usr/bin/env sh

echo $FLAG > flag

export FLAG=not_flag
FLAG=not_flag

rm -rf /flag.sh

chown root:root /var/www/html
chown root:root /var/www/html/JS
chown root:root /var/www/html/bootstrap
chmod 755 /var/www/html



