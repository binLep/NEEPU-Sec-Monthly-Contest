<!DOCTYPE html>
<html>
<head>
    <title>pilipili</title>
	<link rel="icon" href="icon.ico" type="image/x-icon">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style>
        body {
            background: url(1.png) no-repeat center center; /*设置固定背景铺满屏幕*/
            background-size: cover;
            background-attachment: fixed;
        }

        .demo {
            color: mistyrose;
            text-align: center;
            font-family: Verdana;
            font-size: 30px;
            font-weight: bold;
        }

        .stroke {
            -webkit-text-stroke: 0.5px black;
        }
    </style>

    <script type="text/javascript">
        document.oncontextmenu = function () {
            return false;
        }
        document.onkeydown = function (e) {
            var currKey = 0, evt = e || window.event;
            currKey = evt.keyCode || evt.which || evt.charCode;
            if (currKey == 123) {
                window.event.cancelBubble = true;
                window.event.returnValue = false;
            }
        }
    </script>

</head>
<body>
<div class="demo">
    <marquee scrollamount=31 direction=left align=middle>
        <font size="5" color="white" class="stroke"><b>好温柔的歌</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="6" color="#20b2aa" class="stroke"><b>miku! miku! miku!</b></font> &nbsp &nbsp &nbsp
        <font size="4" color="white" class="stroke"><b>好听</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="5" color="white" class="stroke"><b>wa</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="6" color="white" class="stroke"><b>试色</b></font>
    </marquee>
    <marquee scrollamount=13 direction=left align=middle>
        <font size="5" color="#20b2aa" class="stroke"><b>首页通知书</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="7" color="skyblue" class="stroke">376了</font> &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="6" color="#20b2aa" class="stroke"><b>miku! miku! miku!</b></font> &nbsp &nbsp &nbsp
        <font size="6" color="white" class="stroke"><b>试色</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="5" color="white" class="stroke"><b>我手机响了</b></font>
    </marquee>
    <marquee scrollamount=35 direction=left align=middle>
        <font size="5" color="white" class="stroke"><b>MIKU!</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="5" color="#00bfff" class="stroke">泪，射了出来</font>  &nbsp &nbsp &nbsp
        <font size="5" color="white" class="stroke"><b>爱了</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="7" color="white" class="stroke"><b>首页通知书</b></font>
    </marquee>
    <marquee scrollamount=22 direction=left align=middle>
        <font size="6" color="#20b2aa" class="stroke"><b>试色</b></font> &nbsp &nbsp
        <font size="5" color="white" class="stroke"><b>kksk</b></font> &nbsp &nbsp &nbsp &nbsp
        <font size="5" color="#87cefa" class="stroke"><b>泪目</b></font>
    </marquee>
    <marquee scrollamount=14 direction=left align=middle>
        <font size="5" color="white" class="stroke"><b>miku!</b></font> &nbsp &nbsp &nbsp &nbsp
        <font size="6" color="white" class="stroke"><b>我手机响了</b></font>
    </marquee>
    <marquee scrollamount=27 direction=left align=middle>
        <font size="5" color="white" class="stroke"><b>kksk</b></font> &nbsp &nbsp &nbsp &nbsp
        <font size="5" color="#87cefa" class="stroke"><b>泪目</b></font>
    </marquee>
    <marquee scrollamount=44 direction=left align=middle>
        <font size="6" color="#20b2aa" class="stroke">ohhhhh</font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="5" color="#00bfff" class="stroke">泪，冲了下来</font>  &nbsp &nbsp &nbsp
        <font size="5" color="#20b2aa" class="stroke">下次一定</font>
    </marquee>
    <marquee scrollamount=21 direction=left align=middle>
        <font size="5" color="white" class="stroke"><b>wa</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="6" color="white" class="stroke"><b>文艺复兴</b></font>
    </marquee>
    <marquee scrollamount=32 direction=left align=middle>
        <font size="7" color="#00bfff" class="stroke"><b>miku! miku! miku!</b></font>  &nbsp &nbsp &nbsp
        <font size="6" color="white" class="stroke"><b>好看</b></font>
    </marquee>
    <marquee scrollamount=22 direction=left align=middle>
        <font size="6" color="#20b2aa" class="stroke">ohhhhh</font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="5" color="#00bfff" class="stroke">泪，冲了下来</font>  &nbsp &nbsp &nbsp
        <font size="6" color="white" class="stroke"><b>我手机响了</b></font>
    </marquee>
    <marquee scrollamount=26 direction=left align=middle>
        <font size="5" color="white" class="stroke"><b>爱了</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="6" color="#adff2f" class="stroke"><b>爷青回</b></font>
    </marquee>
    <marquee scrollamount=33 direction=left align=middle>
        <font size="7" color="white" class="stroke"><b>awsl</b></font> &nbsp &nbsp &nbsp
        <font size="5" color="white" class="stroke"><b>好听</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="6" color="white" class="stroke"><b>试色</b></font>
    </marquee>
    <marquee scrollamount=31 direction=left align=middle>
        <font size="6" color="white" class="stroke"><b>好想哭啊</b></font> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        <font size="6" color="white" class="stroke"><b>文艺复兴</b></font>
    </marquee>
</div>
</body>

<script src="wocjwovhwovhvwe.js"></script>

</html>