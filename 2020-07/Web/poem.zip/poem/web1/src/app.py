import subprocess
import os
from flask import request
from flask import redirect
from flask import url_for
from flask import render_template
from flask import Flask
from flask import send_file


app = Flask(__name__)

#flag in /flag
@app.route('/')
def get_poem():
    poemname = request.args.get('name')

    if not poemname:
        return render_template("result.html",message=os.listdir('poems'))

    poemdir     = os.path.join(os.getcwd(), 'poems')
    poempath    = os.path.join(poemdir, poemname)

    if '..' in poemname:
        return 'Illegal substring detected.', 403

    if not os.path.exists(poempath):
        return 'File not found.', 404

    return send_file(poempath)


if __name__ == "__main__":
    app.run(host="0.0.0.0",port=5000)